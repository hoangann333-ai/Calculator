package com.codegym;

/** Performs one of the four basic arithmetic operations. */
public class Calculator {
    public double calculate(double firstNumber, double secondNumber, String operator) {
        if (!Double.isFinite(firstNumber) || !Double.isFinite(secondNumber)) {
            throw new IllegalArgumentException("Operands must be finite numbers.");
        }

        return switch (operator) {
            case "+" -> firstNumber + secondNumber;
            case "-" -> firstNumber - secondNumber;
            case "*" -> firstNumber * secondNumber;
            case "/" -> {
                if (secondNumber == 0.0d) {
                    throw new ArithmeticException("Không thể chia cho 0.");
                }
                yield firstNumber / secondNumber;
            }
            default -> throw new IllegalArgumentException("Toán tử không hợp lệ.");
        };
    }
}
