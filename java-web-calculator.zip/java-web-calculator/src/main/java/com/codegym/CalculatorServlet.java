package com.codegym;

import java.io.IOException;
import java.math.BigDecimal;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet(name = "CalculatorServlet", urlPatterns = "/calculate")
public class CalculatorServlet extends HttpServlet {
    private final Calculator calculator = new Calculator();

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        request.setCharacterEncoding("UTF-8");
        response.setContentType("text/html;charset=UTF-8");

        String firstInput = request.getParameter("firstNumber");
        String secondInput = request.getParameter("secondNumber");
        String operator = request.getParameter("operator");

        request.setAttribute("firstInput", firstInput == null ? "" : firstInput);
        request.setAttribute("secondInput", secondInput == null ? "" : secondInput);
        request.setAttribute("operator", operator == null ? "+" : operator);

        try {
            if (firstInput == null || firstInput.isBlank()
                    || secondInput == null || secondInput.isBlank()) {
                throw new IllegalArgumentException("Vui lòng nhập đủ hai toán hạng.");
            }

            if (operator == null) {
                throw new IllegalArgumentException("Vui lòng chọn một phép toán.");
            }
            double first = Double.parseDouble(firstInput.trim());
            double second = Double.parseDouble(secondInput.trim());
            double result = calculator.calculate(first, second, operator);

            if (!Double.isFinite(result)) {
                throw new ArithmeticException("Kết quả vượt quá phạm vi tính toán.");
            }

            String formattedResult = BigDecimal.valueOf(result)
                    .stripTrailingZeros()
                    .toPlainString();
            request.setAttribute("result", formattedResult);
            request.setAttribute("expression", firstInput.trim() + " " + operator + " " + secondInput.trim());
        } catch (NumberFormatException ex) {
            request.setAttribute("error", "Vui lòng nhập các toán hạng dưới dạng số hợp lệ.");
        } catch (ArithmeticException | IllegalArgumentException ex) {
            request.setAttribute("error", ex.getMessage());
        }

        request.getRequestDispatcher("/result.jsp").forward(request, response);
    }
}
