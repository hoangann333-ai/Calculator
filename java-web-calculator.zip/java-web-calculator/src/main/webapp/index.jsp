<%@ page contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" %>
<!doctype html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Máy tính cơ bản</title>
    <style>
        * { box-sizing:border-box; }
        body { min-height:100vh; margin:0; padding:24px; display:grid; place-items:center; background:#f1f5f9; color:#1e293b; font-family:Arial,sans-serif; }
        .calculator { width:min(100%,460px); padding:36px; border-radius:18px; background:#fff; box-shadow:0 16px 48px rgba(15,23,42,.12); }
        .eyebrow { color:#64748b; font-size:.8rem; font-weight:700; letter-spacing:.12em; text-transform:uppercase; }
        h1 { margin:8px 0 8px; color:#1b2a7a; font-size:1.9rem; }
        .subtitle { margin:0 0 24px; color:#64748b; }
        label { display:block; margin:16px 0 7px; font-weight:700; }
        input, select { width:100%; min-height:48px; padding:11px 12px; border:1px solid #cbd5e1; border-radius:8px; font-size:1rem; background:#fff; }
        input:focus, select:focus { outline:3px solid rgba(27,42,122,.14); border-color:#1b2a7a; }
        .operator-label { margin-top:18px; }
        button { width:100%; min-height:48px; margin-top:24px; border:0; border-radius:8px; background:#1b2a7a; color:#fff; font-weight:700; font-size:1rem; cursor:pointer; }
        button:hover { background:#121c54; }
        .operators { display:grid; grid-template-columns:repeat(4,1fr); gap:8px; margin-top:8px; }
        .operators label { margin:0; }
        .operators input { position:absolute; opacity:0; pointer-events:none; }
        .operators span { display:grid; min-height:44px; place-items:center; border:1px solid #cbd5e1; border-radius:8px; color:#1b2a7a; font-size:1.25rem; cursor:pointer; }
        .operators input:checked + span { border-color:#1b2a7a; background:#e9edff; font-weight:700; }
        .operators input:focus-visible + span { outline:3px solid rgba(27,42,122,.2); }
    </style>
</head>
<body>
    <main class="calculator">
        <div class="eyebrow">Java Web · JSP + Servlet</div>
        <h1>Máy tính cơ bản</h1>
        <p class="subtitle">Nhập hai toán hạng và chọn phép tính.</p>
        <form action="${pageContext.request.contextPath}/calculate" method="post">
            <label for="firstNumber">Số thứ nhất</label>
            <input type="number" id="firstNumber" name="firstNumber" step="any" placeholder="Ví dụ: 25" required autofocus>

            <fieldset style="padding:0;border:0;margin:0">
                <legend class="operator-label" style="font-weight:700">Phép toán</legend>
                <div class="operators">
                    <label><input type="radio" name="operator" value="+" checked><span>+</span></label>
                    <label><input type="radio" name="operator" value="-"><span>−</span></label>
                    <label><input type="radio" name="operator" value="*"><span>×</span></label>
                    <label><input type="radio" name="operator" value="/"><span>÷</span></label>
                </div>
            </fieldset>

            <label for="secondNumber">Số thứ hai</label>
            <input type="number" id="secondNumber" name="secondNumber" step="any" placeholder="Ví dụ: 5" required>
            <button type="submit">Tính kết quả</button>
        </form>
    </main>
</body>
</html>
