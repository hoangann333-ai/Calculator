<%@ page contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" %>
<!doctype html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Kết quả máy tính</title>
    <style>
        * { box-sizing:border-box; }
        body { min-height:100vh; margin:0; padding:24px; display:grid; place-items:center; background:#f1f5f9; color:#1e293b; font-family:Arial,sans-serif; }
        .result-card { width:min(100%,520px); padding:clamp(26px,5vw,42px); border-radius:18px; background:#fff; box-shadow:0 16px 48px rgba(15,23,42,.12); text-align:center; }
        .eyebrow { color:#64748b; font-size:.8rem; font-weight:700; letter-spacing:.12em; text-transform:uppercase; }
        h1 { margin:8px 0 24px; color:#1b2a7a; font-size:1.8rem; }
        .expression { color:#64748b; font-size:1.1rem; }
        .answer { margin:20px 0; padding:20px; border-radius:10px; background:#e8f5e9; color:#218c4a; font-size:clamp(1.8rem,8vw,2.6rem); font-weight:700; overflow-wrap:anywhere; }
        .error { margin:20px 0; padding:18px; border-radius:10px; background:#ffebee; color:#b42318; line-height:1.5; }
        .back { display:inline-block; margin-top:8px; padding:12px 20px; border-radius:8px; background:#1b2a7a; color:#fff; text-decoration:none; font-weight:700; }
        .back:hover { background:#121c54; }
    </style>
</head>
<body>
    <main class="result-card">
        <div class="eyebrow">Kết quả tính toán</div>
        <h1>Máy tính cơ bản</h1>
        <% if (request.getAttribute("error") == null) { %>
            <p class="expression"><%= request.getAttribute("expression") %> =</p>
            <div class="answer"><%= request.getAttribute("result") %></div>
        <% } else { %>
            <div class="error"><strong>Không thể thực hiện phép tính.</strong><br><%= request.getAttribute("error") %></div>
        <% } %>
        <a class="back" href="index.jsp">Quay lại máy tính</a>
    </main>
</body>
</html>
