# Java Web Calculator

Ứng dụng Maven JSP/Servlet cho Tomcat 10.1+. Người dùng nhập hai toán hạng, chọn cộng/trừ/nhân/chia. `CalculatorServlet` gọi lớp `Calculator`, xử lý lỗi và forward sang `result.jsp` để hiển thị kết quả.

## Yêu cầu
- JDK 17+
- Maven 3.8+
- Apache Tomcat 10.1+

## Build
Tại thư mục có `pom.xml`, chạy:

```bash
mvn clean package
```

WAR được tạo tại `target/java-web-calculator.war`. Chép WAR vào thư mục `webapps` của Tomcat và khởi động máy chủ.

Mở: http://localhost:8080/java-web-calculator/
